package by.intexsoft.runner;

import java.io.FileNotFoundException;
import java.io.IOException;

import by.intexsoft.jsonparser.element.JsonBaseElement;
import by.intexsoft.jsonparser.exception.NotValidJsonException;
import by.intexsoft.jsonparser.exception.UnsupportedMethodException;
import by.intexsoft.jsonparser.factory.ParserFactory;
import by.intexsoft.jsonparser.parser.BaseParser;
import by.intexsoft.jsonparser.reader.impl.JsonFileReader;
import by.intexsoft.jsonparser.util.UtilityMethods;

public class Runner {

	public static void main(String[] args)
			throws FileNotFoundException, IOException, UnsupportedMethodException, NotValidJsonException {
		System.out.println("Path to file: " + args[0]);
		String arrayJsonString = new JsonFileReader(args[0]).getResult();
		BaseParser parser = ParserFactory.getInstance()
				.getParser(UtilityMethods.removeExtraCharacters(arrayJsonString));
		JsonBaseElement jsonElement = parser.getJsonElement();
 		System.out.println(jsonElement);
		System.out.println("End.");
	}
}
